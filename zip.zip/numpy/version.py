
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.18.1'
version = '1.18.1'
full_version = '1.18.1'
git_revision = '91118b3363b636f932f7ff6748d8259e9eb2c23a'
release = True

if not release:
    version = full_version
